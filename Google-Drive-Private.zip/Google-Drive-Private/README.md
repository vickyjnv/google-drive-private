# Drive Video Downloader

A Chrome extension that captures Google Drive video stream URLs and lets you download the file directly from the popup.

## Features
- Detects Google Drive video streams from the browser debugger
- Extracts the direct MP4 download URL
- Shows the video title in the popup
- Lets you download with one click
- Includes ON/OFF control and a reload button

## Installation
1. Open Chrome and go to `chrome://extensions/`
2. Turn on Developer mode
3. Click Load unpacked
4. Select this project folder
5. Open a Google Drive video and use the extension from the toolbar

## Usage
1. Open a Google Drive video page
2. Click the extension icon
3. Press ON to enable capture
4. Wait for the popup to list the video
5. Click the download button to save the file

## Notes
- Works only on Google Drive video pages
- The extension is meant for personal use of content you have legal access to
- This does not bypass Google Drive protections

