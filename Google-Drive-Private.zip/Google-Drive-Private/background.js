let capturedRequests = {};
let pollingTimers = {};
let autoPopupCount = {};
let extensionEnabled = false;
const pendingTabs = new Set();

chrome.storage.local.get(['extensionEnabled'], (result) => {
    extensionEnabled = result.extensionEnabled || false;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "setEnabled") {
        extensionEnabled = message.enabled;
        
        if (message.enabled) {
            chrome.tabs.get(message.tabId, (tab) => {
                if (chrome.runtime.lastError || !tab) {
                    sendResponse({ success: false });
                    return;
                }
                if (tab.url?.includes("drive.google.com")) {
                    startAutoCaptureForTab(message.tabId);
                    pendingTabs.add(message.tabId);
                }
                sendResponse({ success: true });
            });
            return true;
        } else {
            capturedRequests = {};
            autoPopupCount = {};
            pendingTabs.clear();

            Object.keys(pollingTimers).forEach(tabId => {
                cleanupTabResources(Number(tabId));
            });
            sendResponse({ success: true });
        }
        return true;
    }
    if (message.type === "getRequests") {
        sendResponse({ requests: capturedRequests });
    }
});

function cleanupTabResources(tabId) {
    if (pollingTimers[tabId]) {
        clearInterval(pollingTimers[tabId]);
        delete pollingTimers[tabId];
    }
    const debuggee = { tabId: tabId };
    chrome.debugger.detach(debuggee, () => {
        if (chrome.runtime.lastError) return;
        
        Object.keys(capturedRequests).forEach(requestId => {
            if (capturedRequests[requestId].tabId === tabId) {
                delete capturedRequests[requestId];
            }
        });
        delete autoPopupCount[tabId];
    });
    pendingTabs.delete(tabId);
}

function getQualityHeight(transcode) {
    if (!transcode) return 0;

    const fromLabel = String(transcode.qualityLabel || transcode.quality || '').match(/(\d+)p/i);
    if (fromLabel) return Number(fromLabel[1]);

    return Number(transcode.height || transcode.targetHeight || 0) || 0;
}

const VIDEO_ITAG_PRIORITY = {
    18: 360,
    22: 720,
    37: 1080,
    59: 480,
    78: 480,
    82: 360,
    83: 480,
    84: 720,
    85: 1080,
    87: 1080,
    92: 240,
    93: 360,
    94: 480,
    95: 720,
    96: 1080,
    100: 360,
    101: 480,
    102: 720,
    120: 720,
    121: 1080,
    132: 240,
    133: 240,
    134: 360,
    135: 480,
    136: 720,
    137: 1080,
    138: 2160,
    139: 480,
    140: 0,
    141: 720,
    160: 144,
    167: 360,
    168: 480,
    169: 720,
    170: 1080,
    171: 0,
    218: 480,
    219: 480,
    271: 1080,
    313: 2160,
    315: 2160
};

function getItagHeight(itag) {
    const parsed = Number(itag);
    if (!Number.isFinite(parsed)) return 0;
    return VIDEO_ITAG_PRIORITY[parsed] || 0;
}

function getBestVideoTranscode(transcodes) {
    if (!Array.isArray(transcodes) || transcodes.length === 0) return null;

    const videoTranscodes = transcodes.filter((current) => {
        if (!current || !current.url) return false;

        const mime = String(current.mimeType || current.mime || '');
        const url = String(current.url || '');
        const hasVideoMime = mime.includes('video/') || /mime=video/i.test(url);
        const hasAudioMime = mime.includes('audio/') || /mime=audio/i.test(url);
        const hasItag = Number.isFinite(Number(current.itag));
        const height = getQualityHeight(current) || getItagHeight(current.itag);
        return (hasVideoMime || height > 0 || hasItag) && !hasAudioMime;
    });

    if (videoTranscodes.length === 0) return null;

    return videoTranscodes.reduce((best, current) => {
        const currentHeight = getQualityHeight(current) || getItagHeight(current.itag);
        const bestHeight = getQualityHeight(best) || getItagHeight(best.itag);
        const currentBytes = Number(current.contentLength || current.approximateBytes || 0);
        const bestBytes = Number(best.contentLength || best.approximateBytes || 0);
        const currentFps = Number(current.fps || 0);
        const bestFps = Number(best.fps || 0);

        if (currentHeight !== bestHeight) return currentHeight > bestHeight ? current : best;
        if (currentBytes !== bestBytes) return currentBytes > bestBytes ? current : best;
        if (currentFps !== bestFps) return currentFps > bestFps ? current : best;

        return current.itag > best.itag ? current : best;
    }, videoTranscodes[0]);
}

function parseVideoUrlDetails(url) {
    try {
        const parsed = new URL(url);
        const params = new URLSearchParams(parsed.search);
        const mime = params.get('mime') || '';
        const itag = params.get('itag');
        const clen = params.get('clen');
        const quality = params.get('quality_label') || params.get('quality') || '';
        const height = Number(params.get('height') || 0);

        return {
            url,
            mimeType: mime,
            itag: itag ? Number(itag) : undefined,
            contentLength: clen ? Number(clen) : 0,
            qualityLabel: quality || (getItagHeight(Number(itag)) ? `${getItagHeight(Number(itag))}p` : ''),
            height: height || getItagHeight(Number(itag)) || 0,
            mime: mime,
            quality: quality
        };
    } catch (e) {
        return null;
    }
}

function startAutoCaptureForTab(tabId) {
    cleanupTabResources(tabId);
    
    const debuggee = { tabId: tabId };
    chrome.debugger.attach(debuggee, "1.3", () => {
        if (chrome.runtime.lastError) return;
        
        chrome.debugger.sendCommand(debuggee, "Network.enable", {}, () => {
            pollingTimers[tabId] = setInterval(() => {
                let validRequests = [];
                for (const requestId in capturedRequests) {
                    const req = capturedRequests[requestId];
                    const videoUrl = req.bestItagUrl || req.lastItagUrl;
                    if (req.tabId === tabId && videoUrl && req.videoTitle) {
                        validRequests.push(req);
                    }
                }

                let currentCount = validRequests.length;
                if (!autoPopupCount[tabId]) autoPopupCount[tabId] = 0;

                if (currentCount > autoPopupCount[tabId]) {
                    autoPopupCount[tabId] = currentCount;
                    chrome.windows.getLastFocused({ populate: false }, (window) => {
                        if (window && window.type === 'normal') {
                            try {
                                chrome.action.openPopup();
                            } catch (e) {
                            }
                        }
                    });
                }
            }, 1000);
        });
    });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url?.startsWith("https://drive.google.com/")) {
        if (extensionEnabled || pendingTabs.has(tabId)) {
            if (!pollingTimers[tabId]) {
                startAutoCaptureForTab(tabId);
            }
            pendingTabs.delete(tabId);
        }
    }
});

chrome.tabs.onRemoved.addListener((tabId) => {
    cleanupTabResources(tabId);
});

chrome.debugger.onEvent.addListener((debuggeeId, method, params) => {
    const tabId = debuggeeId.tabId;
    if (!extensionEnabled && !pendingTabs.has(tabId)) return;

    if (method === "Network.requestWillBeSent") {
        const requestUrl = params.request?.url || '';
        const isDriveVideoRequest = requestUrl.includes("videoplayback") || requestUrl.includes("workspacevideo-pa.clients6.google.com");

        if (isDriveVideoRequest) {
            const requestId = params.requestId;
            const parsed = parseVideoUrlDetails(requestUrl);
            capturedRequests[requestId] = {
                url: requestUrl,
                method: params.request.method,
                timestamp: params.timestamp,
                tabId: tabId,
                ...parsed
            };

            const urlMime = String(parsed?.mimeType || '').toLowerCase();
            const itag = Number(parsed?.itag);
            const isAudioOnly = urlMime.includes('audio/') || (Number.isFinite(itag) && (itag === 140 || itag === 171 || itag === 251 || itag === 139 || itag === 140));

            if (!isAudioOnly && parsed?.url) {
                capturedRequests[requestId].bestItagUrl = parsed.url;
                capturedRequests[requestId].lastItagUrl = parsed.url;
                capturedRequests[requestId].videoQuality = parsed.qualityLabel || (parsed.height ? `${parsed.height}p` : 'Best');
                capturedRequests[requestId].fileSizeBytes = Number(parsed.contentLength || 0);
                capturedRequests[requestId].fileSize = capturedRequests[requestId].fileSizeBytes > 0
                    ? (() => {
                        const size = capturedRequests[requestId].fileSizeBytes;
                        if (size >= 1073741824) return `${(size / 1073741824).toFixed(1)} GB`;
                        if (size >= 1048576) return `${(size / 1048576).toFixed(1)} MB`;
                        if (size >= 1024) return `${(size / 1024).toFixed(1)} KB`;
                        return `${size} B`;
                    })()
                    : 'Unknown size';
            }
        }
    } else if (method === "Network.responseReceived") {
        const requestId = params.requestId;
        if (capturedRequests[requestId]) {
            chrome.debugger.sendCommand(
                { tabId: tabId },
                "Network.getResponseBody",
                { requestId: requestId },
                (result) => {
                    if (chrome.runtime.lastError) return;
                    capturedRequests[requestId].responseBody = result.body;
                    capturedRequests[requestId].base64Encoded = result.base64Encoded;

                    try {
                        const data = JSON.parse(result.body);
                        if (data.mediaStreamingData?.formatStreamingData?.progressiveTranscodes) {
                            const transcodes = data.mediaStreamingData.formatStreamingData.progressiveTranscodes;
                            const bestTranscode = getBestVideoTranscode(transcodes);
                            if (bestTranscode?.url) {
                                capturedRequests[requestId].bestItagUrl = bestTranscode.url;
                                capturedRequests[requestId].lastItagUrl = bestTranscode.url;
                                capturedRequests[requestId].videoQuality = bestTranscode.qualityLabel || (bestTranscode.height ? `${bestTranscode.height}p` : 'Best');
                                capturedRequests[requestId].fileSizeBytes = Number(bestTranscode.contentLength || 0);
                                capturedRequests[requestId].fileSize = capturedRequests[requestId].fileSizeBytes > 0
                                    ? (() => {
                                        const size = capturedRequests[requestId].fileSizeBytes;
                                        if (size >= 1073741824) return `${(size / 1073741824).toFixed(1)} GB`;
                                        if (size >= 1048576) return `${(size / 1048576).toFixed(1)} MB`;
                                        if (size >= 1024) return `${(size / 1024).toFixed(1)} KB`;
                                        return `${size} B`;
                                    })()
                                    : 'Unknown size';
                            }
                        }
                    } catch (e) {
                        if (capturedRequests[requestId]?.url && !capturedRequests[requestId].bestItagUrl) {
                            const parsed = parseVideoUrlDetails(capturedRequests[requestId].url);
                            if (parsed && !String(parsed.mimeType || '').toLowerCase().includes('audio/')) {
                                capturedRequests[requestId].bestItagUrl = parsed.url;
                                capturedRequests[requestId].lastItagUrl = parsed.url;
                                capturedRequests[requestId].videoQuality = parsed.qualityLabel || (parsed.height ? `${parsed.height}p` : 'Best');
                                capturedRequests[requestId].fileSizeBytes = Number(parsed.contentLength || 0);
                                capturedRequests[requestId].fileSize = capturedRequests[requestId].fileSizeBytes > 0
                                    ? (() => {
                                        const size = capturedRequests[requestId].fileSizeBytes;
                                        if (size >= 1073741824) return `${(size / 1073741824).toFixed(1)} GB`;
                                        if (size >= 1048576) return `${(size / 1048576).toFixed(1)} MB`;
                                        if (size >= 1024) return `${(size / 1024).toFixed(1)} KB`;
                                        return `${size} B`;
                                    })()
                                    : 'Unknown size';
                            }
                        }
                    }

                    const rawTitle = capturedRequests[requestId].videoTitle || '';
                    if (!rawTitle) {
                        chrome.tabs.get(tabId, (tab) => {
                            if (tab?.title) {
                                const tabTitle = tab.title.replace(/\s*-\s*Google Drive$/i, '').trim();
                                if (tabTitle && !/videoplayback/i.test(tabTitle)) {
                                    capturedRequests[requestId].videoTitle = tabTitle;
                                }
                            }
                        });
                    }
                }
            );
        }
    }
});