document.addEventListener("DOMContentLoaded", () => {
    const header = document.querySelector('.header');
    const notDriveMessage = document.getElementById('notDriveMessage');
    const downloadContainer = document.getElementById('downloadContainer');
    const statusMessage = document.getElementById('statusMessage');
    const btnOn = document.getElementById('btnOn');
    const btnOff = document.getElementById('btnOff');
    const reloadBtn = document.querySelector('.reload-btn');

    function sanitizeFileName(name) {
        const raw = (name || 'video').toString()
            .replace(/\s*-\s*Google Drive$/i, '')
            .replace(/\bvideoplayback\b/gi, '')
            .trim();

        const clean = raw
            .replace(/[<>:"/\\|?*]+/g, '_')
            .replace(/\s+/g, ' ')
            .trim();

        return clean || 'video';
    }

    function formatQualityLabel(req) {
        const quality = req.videoQuality || 'Best';
        const size = req.fileSize || 'Unknown size';
        return `${quality} • ${size}`;
    }

    function updateUI(isEnabled) {
    btnOn.disabled = isEnabled;
    btnOff.disabled = !isEnabled;
    reloadBtn.classList.toggle('active', isEnabled);
	}

    function handleStateChange(newState) {
        chrome.storage.local.set({ extensionEnabled: newState }, () => {
            updateUI(newState);
            
            if (!newState) {
                downloadContainer.innerHTML = '';
                statusMessage.textContent = "Extension stopped.";
                setTimeout(() => {
                    statusMessage.textContent = "Click ON to start extension.";
                }, 2000);
            }

            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const tab = tabs[0];
                if (!tab) return;

                chrome.runtime.sendMessage({ 
                    type: "setEnabled", 
                    enabled: newState,
                    tabId: tab.id,
                    url: tab.url
                }, (response) => {
                    if (newState && response?.success) {
                        chrome.tabs.reload(tab.id);
                    }
                });
            });
        });
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab || !tab.url.startsWith('https://drive.google.com/')) {
            header.classList.add('hidden');
            downloadContainer.classList.add('hidden');
            statusMessage.classList.add('hidden');
            notDriveMessage.classList.remove('hidden');
            return;
        }

        header.classList.remove('hidden');
        downloadContainer.classList.remove('hidden');
        statusMessage.classList.remove('hidden');
        notDriveMessage.classList.add('hidden');

		chrome.storage.local.get(['extensionEnabled'], (result) => {
			const isEnabled = result.extensionEnabled !== undefined ? result.extensionEnabled : false;
			updateUI(isEnabled);
		});

        btnOn.addEventListener('click', () => handleStateChange(true));
        btnOff.addEventListener('click', () => handleStateChange(false));

        reloadBtn.addEventListener('click', () => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]?.id) {
                    chrome.tabs.reload(tabs[0].id);
                }
            });
        });

        const activeTabId = tab.id;
        setInterval(() => {
            chrome.runtime.sendMessage({ type: "getRequests" }, (response) => {
                if (response && response.requests) {
                    const matchingRequests = [];
                    for (const requestId in response.requests) {
                        const req = response.requests[requestId];
                        const videoUrl = req.bestItagUrl || req.lastItagUrl;
                        if (req.tabId === activeTabId && videoUrl && req.videoTitle) {
                            matchingRequests.push(req);
                        }
                    }
                    if (matchingRequests.length > 0) {
                        statusMessage.textContent = "";
                        downloadContainer.innerHTML = "";
                        matchingRequests.forEach((req) => {
                            const item = document.createElement("div");
                            item.classList.add("video-item");

                            const infoBlock = document.createElement("div");
                            infoBlock.classList.add("video-info");

                            const titleSpan = document.createElement("span");
                            titleSpan.classList.add("video-title");
                            titleSpan.textContent = req.videoTitle.length > 35
                                ? req.videoTitle.substring(0, 35) + "..." 
                                : req.videoTitle;

                            const metaRow = document.createElement("div");
                            metaRow.classList.add("video-meta");

                            const qualityBadge = document.createElement("span");
                            qualityBadge.classList.add("quality-badge");
                            qualityBadge.textContent = formatQualityLabel(req);

                            metaRow.appendChild(qualityBadge);
                            infoBlock.appendChild(titleSpan);
                            infoBlock.appendChild(metaRow);

                            const btn = document.createElement("button");
                            btn.classList.add("download-btn");
                            btn.textContent = "Download";
                            btn.addEventListener("click", () => {
                                const videoUrl = req.bestItagUrl || req.lastItagUrl;
                                const safeTitle = sanitizeFileName(req.videoTitle || 'video');
                                chrome.downloads.download({
                                    url: videoUrl,
                                    filename: `${safeTitle}.mp4`
                                }, () => {
                                    if (chrome.runtime.lastError) {
                                        statusMessage.textContent = "Can't able to download";
                                        statusMessage.classList.add("error");
                                    }
                                });
                            });

                            item.appendChild(infoBlock);
                            item.appendChild(btn);
                            downloadContainer.appendChild(item);
                        });
                    } else {
                        chrome.storage.local.get(['extensionEnabled'], (result) => {
                            if (result.extensionEnabled) {
                                statusMessage.textContent = "Waiting for new video source. If not working reload the page.";
                            }
                        });
                    }
                }
            });
        }, 1000);
    });
});